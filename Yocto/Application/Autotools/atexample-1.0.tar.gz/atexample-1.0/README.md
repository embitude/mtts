bb-example
==========

Example Yocto/OpenEmbedded autotooled recipe, building an executable with a dependency on a shared library

